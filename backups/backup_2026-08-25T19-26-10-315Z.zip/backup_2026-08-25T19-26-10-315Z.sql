--
-- PostgreSQL database dump
--

\restrict wMJ7ebV6XuID1AohilLUYnPnw5sDtIRBA1wNJ4a9UjhqMcIKH4SiawThaisgRQ3

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.stock_adjustments DROP CONSTRAINT IF EXISTS "stock_adjustments_productId_fkey";
ALTER TABLE IF EXISTS ONLY public.stock_adjustments DROP CONSTRAINT IF EXISTS "stock_adjustments_createdById_fkey";
ALTER TABLE IF EXISTS ONLY public.shift_reports DROP CONSTRAINT IF EXISTS "shift_reports_cashierId_fkey";
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS "sales_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS "sales_cashierId_fkey";
ALTER TABLE IF EXISTS ONLY public.sale_payments DROP CONSTRAINT IF EXISTS "sale_payments_saleId_fkey";
ALTER TABLE IF EXISTS ONLY public.sale_items DROP CONSTRAINT IF EXISTS "sale_items_saleId_fkey";
ALTER TABLE IF EXISTS ONLY public.sale_items DROP CONSTRAINT IF EXISTS "sale_items_productId_fkey";
ALTER TABLE IF EXISTS ONLY public.purchase_orders DROP CONSTRAINT IF EXISTS "purchase_orders_supplierId_fkey";
ALTER TABLE IF EXISTS ONLY public.purchase_orders DROP CONSTRAINT IF EXISTS "purchase_orders_createdById_fkey";
ALTER TABLE IF EXISTS ONLY public.purchase_order_items DROP CONSTRAINT IF EXISTS "purchase_order_items_purchaseOrderId_fkey";
ALTER TABLE IF EXISTS ONLY public.purchase_order_items DROP CONSTRAINT IF EXISTS "purchase_order_items_productId_fkey";
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS "products_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS "products_brandId_fkey";
ALTER TABLE IF EXISTS ONLY public.held_carts DROP CONSTRAINT IF EXISTS "held_carts_cashierId_fkey";
DROP INDEX IF EXISTS public.users_phone_key;
DROP INDEX IF EXISTS public."sales_invoiceNo_key";
DROP INDEX IF EXISTS public."sales_invoiceNo_idx";
DROP INDEX IF EXISTS public."sales_createdAt_idx";
DROP INDEX IF EXISTS public."purchase_orders_invoiceNo_key";
DROP INDEX IF EXISTS public.products_sku_key;
DROP INDEX IF EXISTS public.products_sku_idx;
DROP INDEX IF EXISTS public.products_barcode_key;
DROP INDEX IF EXISTS public.products_barcode_idx;
DROP INDEX IF EXISTS public.customers_phone_key;
DROP INDEX IF EXISTS public.categories_name_key;
DROP INDEX IF EXISTS public.brands_name_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.suppliers DROP CONSTRAINT IF EXISTS suppliers_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_adjustments DROP CONSTRAINT IF EXISTS stock_adjustments_pkey;
ALTER TABLE IF EXISTS ONLY public.shift_reports DROP CONSTRAINT IF EXISTS shift_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_pkey;
ALTER TABLE IF EXISTS ONLY public.sale_payments DROP CONSTRAINT IF EXISTS sale_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.sale_items DROP CONSTRAINT IF EXISTS sale_items_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_orders DROP CONSTRAINT IF EXISTS purchase_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_order_items DROP CONSTRAINT IF EXISTS purchase_order_items_pkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.held_carts DROP CONSTRAINT IF EXISTS held_carts_pkey;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.brands DROP CONSTRAINT IF EXISTS brands_pkey;
ALTER TABLE IF EXISTS ONLY public.backup_logs DROP CONSTRAINT IF EXISTS backup_logs_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.suppliers;
DROP TABLE IF EXISTS public.stock_adjustments;
DROP TABLE IF EXISTS public.shift_reports;
DROP TABLE IF EXISTS public.sales;
DROP TABLE IF EXISTS public.sale_payments;
DROP TABLE IF EXISTS public.sale_items;
DROP TABLE IF EXISTS public.purchase_orders;
DROP TABLE IF EXISTS public.purchase_order_items;
DROP TABLE IF EXISTS public.products;
DROP TABLE IF EXISTS public.held_carts;
DROP TABLE IF EXISTS public.customers;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.brands;
DROP TABLE IF EXISTS public.backup_logs;
DROP TYPE IF EXISTS public."Role";
DROP TYPE IF EXISTS public."PurchaseStatus";
DROP TYPE IF EXISTS public."PaymentStatus";
DROP TYPE IF EXISTS public."PaymentMethod";
DROP TYPE IF EXISTS public."BackupStatus";
DROP TYPE IF EXISTS public."AdjustmentType";
--
-- Name: AdjustmentType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AdjustmentType" AS ENUM (
    'DAMAGE',
    'LOSS',
    'RETURN',
    'CORRECTION'
);


--
-- Name: BackupStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BackupStatus" AS ENUM (
    'SUCCESS',
    'FAILED'
);


--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'CASH',
    'CARD',
    'BKASH',
    'NAGAD',
    'ROCKET',
    'STORE_CREDIT'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PAID',
    'PARTIAL',
    'CREDIT'
);


--
-- Name: PurchaseStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PurchaseStatus" AS ENUM (
    'PENDING',
    'PARTIAL',
    'PAID'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'MANAGER',
    'CASHIER'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: backup_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_logs (
    id text NOT NULL,
    filename text NOT NULL,
    "fileSize" bigint,
    status public."BackupStatus" NOT NULL,
    "driveFileId" text,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: brands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brands (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id text NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    email text,
    address text,
    "loyaltyPoints" integer DEFAULT 0 NOT NULL,
    "storeCreditDue" numeric(12,2) DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: held_carts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.held_carts (
    id text NOT NULL,
    "cashierId" text NOT NULL,
    label text,
    "cartJson" jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id text NOT NULL,
    name text NOT NULL,
    sku text,
    barcode text,
    "categoryId" text NOT NULL,
    "brandId" text,
    "costPrice" numeric(12,2) NOT NULL,
    "salePrice" numeric(12,2) NOT NULL,
    unit text DEFAULT 'pcs'::text NOT NULL,
    "currentStock" numeric(12,3) DEFAULT 0 NOT NULL,
    "lowStockThreshold" numeric(12,3) DEFAULT 10 NOT NULL,
    "expiryDate" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_items (
    id text NOT NULL,
    "purchaseOrderId" text NOT NULL,
    "productId" text NOT NULL,
    qty numeric(12,3) NOT NULL,
    "costPrice" numeric(12,2) NOT NULL,
    subtotal numeric(12,2) NOT NULL
);


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id text NOT NULL,
    "supplierId" text NOT NULL,
    "invoiceNo" text NOT NULL,
    "totalAmount" numeric(12,2) NOT NULL,
    "amountPaid" numeric(12,2) DEFAULT 0 NOT NULL,
    status public."PurchaseStatus" DEFAULT 'PENDING'::public."PurchaseStatus" NOT NULL,
    notes text,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: sale_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_items (
    id text NOT NULL,
    "saleId" text NOT NULL,
    "productId" text NOT NULL,
    qty numeric(12,3) NOT NULL,
    "unitPrice" numeric(12,2) NOT NULL,
    "discountAmount" numeric(12,2) DEFAULT 0 NOT NULL,
    subtotal numeric(12,2) NOT NULL
);


--
-- Name: sale_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_payments (
    id text NOT NULL,
    "saleId" text NOT NULL,
    method public."PaymentMethod" NOT NULL,
    amount numeric(12,2) NOT NULL,
    reference text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales (
    id text NOT NULL,
    "invoiceNo" text NOT NULL,
    "cashierId" text NOT NULL,
    "customerId" text,
    subtotal numeric(12,2) NOT NULL,
    "discountAmount" numeric(12,2) DEFAULT 0 NOT NULL,
    "totalAmount" numeric(12,2) NOT NULL,
    "paymentStatus" public."PaymentStatus" DEFAULT 'PAID'::public."PaymentStatus" NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: shift_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shift_reports (
    id text NOT NULL,
    "cashierId" text NOT NULL,
    "openingFloat" numeric(12,2) NOT NULL,
    "expectedCash" numeric(12,2) NOT NULL,
    "actualCash" numeric(12,2) NOT NULL,
    variance numeric(12,2) NOT NULL,
    "totalSales" numeric(12,2) NOT NULL,
    "totalTransactions" integer NOT NULL,
    notes text,
    "closedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: stock_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_adjustments (
    id text NOT NULL,
    "productId" text NOT NULL,
    qty numeric(12,3) NOT NULL,
    reason text NOT NULL,
    type public."AdjustmentType" NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id text NOT NULL,
    name text NOT NULL,
    contact text,
    phone text,
    address text,
    "totalDue" numeric(12,2) DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    "passwordHash" text NOT NULL,
    role public."Role" DEFAULT 'CASHIER'::public."Role" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: backup_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_logs (id, filename, "fileSize", status, "driveFileId", "errorMessage", "createdAt") FROM stdin;
511252a7-55d6-4d18-a8b4-ae0517971a9d	backup_2026-08-25T19-01-46-106Z.zip	\N	FAILED	\N	pg_dump error: Command failed: pg_dump "postgresql://postgres:1234@localhost:5432/pos_db" > "/Users/mtarekrahman/Desktop/ShopManagement/backups/backup_2026-08-25T19-01-46-106Z.sql"\n/bin/sh: pg_dump: command not found\n	2026-08-25 19:01:46.123
9c2c1ae6-e8a0-40cd-bbbe-72b32be782a0	backup_2026-08-25T19-03-21-941Z.zip	\N	FAILED	\N	pg_dump error: Command failed: pg_dump "postgresql://postgres:1234@localhost:5432/pos_db" > "/Users/mtarekrahman/Desktop/ShopManagement/backups/backup_2026-08-25T19-03-21-941Z.sql"\n/bin/sh: pg_dump: command not found\n	2026-08-25 19:03:21.953
d1871804-884a-48e5-8807-7308c8762a62	backup_2026-08-25T19-10-14-099Z.zip	\N	FAILED	\N	pg_dump error: Command failed: pg_dump "postgresql://postgres:1234@localhost:5432/pos_db" > "/Users/mtarekrahman/Desktop/ShopManagement/backups/backup_2026-08-25T19-10-14-099Z.sql"\n/bin/sh: pg_dump: command not found\n	2026-08-25 19:10:14.115
d1f0d3b2-2945-4f3b-82f5-3fa79de09a60	backup_2026-08-25T19-11-05-470Z.zip	7330	SUCCESS	\N	Local archive saved securely. Automated retention applied.	2026-08-25 19:11:05.965
af4f74fd-66bb-47a6-be2d-a1977382c80b	backup_2026-08-25T19-14-34-397Z.zip	7427	SUCCESS	\N	Local archive saved securely. Automated retention applied.	2026-08-25 19:14:34.524
af9826d1-cf43-44e5-9f3e-8c8f1bac96e0	backup_2026-08-25T19-23-54-435Z.zip	12510	SUCCESS	\N	Local archive saved securely.	2026-08-25 19:23:54.582
381a33c8-51e4-4831-b35c-6abe09d7800b	backup_2026-08-25T19-24-44-065Z.zip	12549	SUCCESS	\N	Local archive saved securely.	2026-08-25 19:24:44.199
\.


--
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.brands (id, name, description, "isActive") FROM stdin;
049327a8-e4cc-45b4-8705-664d20ce65d3	Generic	\N	t
37b92bd9-7998-4f70-916f-ed91c15ffb56	Local Brand	\N	t
d86da400-79e4-4f24-83b9-54a6728dd175	Fresh Loose (খোলা পণ্য)	\N	t
b9beeefe-6e70-4215-9532-39d277d84053	Pran	\N	t
d1913fbc-63a1-4096-9905-beca823b3bfa	Aarong	\N	t
1885fce9-a351-4b49-9ba5-29d160ece133	Square	\N	t
51acde94-daaa-43e2-8efd-d177c4a51947	Teer	\N	t
5d5fd9ed-32bb-4833-ba76-b784009b836d	amar food	\N	t
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, description, "isActive") FROM stdin;
bdd40ab4-b0b3-42c0-9dd9-6c2f73456af1	Electronics (ইলেকট্রনিক্স)	\N	t
76784d80-1916-4b98-9607-ca26b2472610	Pharmacy (ফার্মেসি ও ওষুধ)	\N	t
36176d1f-ec68-4e30-9a55-a0fd547cc836	Grocery (মুদি ও নিত্যপণ্য)	\N	t
6d32573c-bbdb-4e48-bcf5-bf15afdf80eb	Beverages (পানীয় ও জুস)	\N	t
d35c238b-ed99-4e85-824e-337efb6f2b3b	Snacks (স্ন্যাক্স ও বিস্কুট)	\N	t
070c1763-74bc-49fb-872b-1299fed1d49f	Bakery & Snacks (বেকারি ও স্ন্যাক্স)	\N	t
8e037793-3ff0-4b79-b8e1-ade0f18b1e23	Packaged Foods (প্যাকেটজাত খাবার)	\N	t
c3e781bc-1217-44c8-96b5-7439092b9a7c	Vegetables & Fresh (কাঁচা বাজার)	\N	t
48b5c852-1571-4c4d-9983-b69abbfa2ca0	Rice, Dal & Grains (চাল ও ডাল)	\N	t
9cef80dd-5321-43af-96c2-8bbecaa1bd7b	Spices & Oil (তেল ও মশলা)	\N	t
ceb128dc-d9f3-4f5f-a79e-def8315bcce4	Dairy & Eggs (দুধ ও ডিম)	\N	t
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, phone, email, address, "loyaltyPoints", "storeCreditDue", "isActive", "createdAt", "updatedAt") FROM stdin;
11362269-6172-4132-a12d-bb8a0ba4db1f	Walk-in Customer	00000000000	\N	\N	0	0.00	t	2026-08-25 12:23:00.639	2026-08-25 19:25:16.999
\.


--
-- Data for Name: held_carts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.held_carts (id, "cashierId", label, "cartJson", "createdAt") FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, sku, barcode, "categoryId", "brandId", "costPrice", "salePrice", unit, "currentStock", "lowStockThreshold", "expiryDate", "isActive", "createdAt", "updatedAt") FROM stdin;
ba857e79-cd79-4472-af17-fe5b03b29371	Miniket Premium Rice (মিনিকেট চাল)	GRAIN-MINIKET	\N	48b5c852-1571-4c4d-9983-b69abbfa2ca0	d86da400-79e4-4f24-83b9-54a6728dd175	65.00	74.00	kg	499.500	50.000	\N	t	2026-08-25 17:31:36.434	2026-08-25 19:25:17.009
b4954a19-be5c-4be3-9ce2-c73b3e460715	Local Onion (দেশি পেঁয়াজ)	VEG-ONION	\N	c3e781bc-1217-44c8-96b5-7439092b9a7c	d86da400-79e4-4f24-83b9-54a6728dd175	75.00	90.00	kg	249.750	25.000	\N	t	2026-08-25 17:31:36.43	2026-08-25 19:25:17.009
f919c811-1a84-40dc-8475-2a7ac7b879e2	alu	\N	\N	c3e781bc-1217-44c8-96b5-7439092b9a7c	\N	1200.00	1500.00	10 kg 	0.000	10.000	\N	t	2026-08-25 18:45:00.603	2026-08-25 19:25:17.009
e055d820-052b-4772-93c3-50c65937d64f	Red Potato (গোল আলু)	VEG-POTATO	\N	c3e781bc-1217-44c8-96b5-7439092b9a7c	d86da400-79e4-4f24-83b9-54a6728dd175	30.00	40.00	kg	299.500	20.000	\N	t	2026-08-25 17:31:36.426	2026-08-25 19:25:17.009
37b57595-d5d9-452b-af1b-8bb3e7537b3a	Aarong Liquid Milk 1L	DAIRY-AARONG-1L	8901234561002	ceb128dc-d9f3-4f5f-a79e-def8315bcce4	d1913fbc-63a1-4096-9905-beca823b3bfa	85.00	95.00	pack	79.000	15.000	\N	t	2026-08-25 17:31:36.437	2026-08-25 19:25:17.009
b3bc8db0-225b-4da9-8364-19a363ab38cd	Basmati Rice 1kg	GROC-001	8901234560003	36176d1f-ec68-4e30-9a55-a0fd547cc836	37b92bd9-7998-4f70-916f-ed91c15ffb56	75.00	95.00	kg	100.000	20.000	\N	t	2026-08-25 12:23:00.636	2026-08-25 19:25:17.009
b56b0bc8-04cb-4e64-9f5f-d846784ca551	Mineral Water 500ml	BEV-001	8901234560004	6d32573c-bbdb-4e48-bcf5-bf15afdf80eb	049327a8-e4cc-45b4-8705-664d20ce65d3	10.00	15.00	bottle	300.000	50.000	\N	t	2026-08-25 12:23:00.637	2026-08-25 19:25:17.009
95d3d642-3afd-44ff-8f94-d13e43d788a7	Paracetamol 500mg (Strip of 10)	PHAR-001	8901234560002	76784d80-1916-4b98-9607-ca26b2472610	37b92bd9-7998-4f70-916f-ed91c15ffb56	8.00	12.00	strip	200.000	50.000	2027-12-31 00:00:00	t	2026-08-25 12:23:00.635	2026-08-25 19:25:17.009
291adaeb-46fe-4070-baf4-eb1b49d688db	Potato Chips 100g	SNCK-001	8901234560005	d35c238b-ed99-4e85-824e-337efb6f2b3b	37b92bd9-7998-4f70-916f-ed91c15ffb56	25.00	35.00	pcs	150.000	30.000	2027-06-30 00:00:00	t	2026-08-25 12:23:00.637	2026-08-25 19:25:17.009
b941a581-31be-433c-aa3d-b611a4e606e2	USB-C Charging Cable 2m	ELEC-001	8901234560001	bdd40ab4-b0b3-42c0-9dd9-6c2f73456af1	049327a8-e4cc-45b4-8705-664d20ce65d3	120.00	199.00	pcs	50.000	10.000	\N	t	2026-08-25 12:23:00.632	2026-08-25 19:25:17.009
4c3bca03-100e-4d80-80c6-a76283632e1c	Garlic (দেশি রসুন)	VEG-GARLIC	\N	c3e781bc-1217-44c8-96b5-7439092b9a7c	d86da400-79e4-4f24-83b9-54a6728dd175	160.00	190.00	kg	80.000	10.000	\N	t	2026-08-25 17:31:36.431	2026-08-25 19:25:17.009
4eaccf9a-1a24-46e3-bcf8-0fc0688cf197	Ginger (আদা)	VEG-GINGER	\N	c3e781bc-1217-44c8-96b5-7439092b9a7c	d86da400-79e4-4f24-83b9-54a6728dd175	180.00	220.00	kg	60.000	10.000	\N	t	2026-08-25 17:31:36.431	2026-08-25 19:25:17.009
edebde8d-f16e-4ebf-a55f-1cfe53d126a3	Green Chili (কাঁচা মরিচ)	VEG-CHILI	\N	c3e781bc-1217-44c8-96b5-7439092b9a7c	d86da400-79e4-4f24-83b9-54a6728dd175	120.00	160.00	kg	40.000	5.000	\N	t	2026-08-25 17:31:36.432	2026-08-25 19:25:17.009
31b89040-cc26-4b2e-89a1-ef22a85669b8	Fresh Tomato (টমেটো)	VEG-TOMATO	\N	c3e781bc-1217-44c8-96b5-7439092b9a7c	d86da400-79e4-4f24-83b9-54a6728dd175	45.00	60.00	kg	100.000	15.000	\N	t	2026-08-25 17:31:36.432	2026-08-25 19:25:17.009
635d861c-44de-45ad-8bc1-1d56c5578cf2	Fresh Cow Milk (গরুর দুধ)	DAIRY-MILK	\N	ceb128dc-d9f3-4f5f-a79e-def8315bcce4	d86da400-79e4-4f24-83b9-54a6728dd175	65.00	80.00	litre	60.000	10.000	\N	t	2026-08-25 17:31:36.433	2026-08-25 19:25:17.009
675bbbba-ce7b-48ba-9871-a0393439588f	Nazirshail Rice (নাজিরশাইল চাল)	GRAIN-NAZIR	\N	48b5c852-1571-4c4d-9983-b69abbfa2ca0	d86da400-79e4-4f24-83b9-54a6728dd175	75.00	86.00	kg	400.000	40.000	\N	t	2026-08-25 17:31:36.435	2026-08-25 19:25:17.009
b4a68ecc-1459-402a-b70b-69e71309213a	Masoor Dal (দেশি মসুর ডাল)	GRAIN-DAL	\N	48b5c852-1571-4c4d-9983-b69abbfa2ca0	d86da400-79e4-4f24-83b9-54a6728dd175	120.00	140.00	kg	150.000	20.000	\N	t	2026-08-25 17:31:36.435	2026-08-25 19:25:17.009
983d4655-235d-43cf-a495-5c594bdd3203	Loose White Sugar (খোলা চিনি)	GRAIN-SUGAR	\N	48b5c852-1571-4c4d-9983-b69abbfa2ca0	d86da400-79e4-4f24-83b9-54a6728dd175	125.00	135.00	kg	200.000	25.000	\N	t	2026-08-25 17:31:36.436	2026-08-25 19:25:17.009
1c2d8310-c602-4e08-b037-32dbd270f330	Teer Fortified Soybean Oil 1L	OIL-TEER-1L	8901234561001	9cef80dd-5321-43af-96c2-8bbecaa1bd7b	51acde94-daaa-43e2-8efd-d177c4a51947	175.00	185.00	bottle	120.000	20.000	\N	t	2026-08-25 17:31:36.436	2026-08-25 19:25:17.009
a820cd58-c635-41e0-be07-7ffaf021ea6f	Pran Frooto Mango Drink 250ml	BEV-FROOTO-250	8901234561003	8e037793-3ff0-4b79-b8e1-ade0f18b1e23	b9beeefe-6e70-4215-9532-39d277d84053	22.00	28.00	bottle	150.000	30.000	\N	t	2026-08-25 17:31:36.438	2026-08-25 19:25:17.009
96aa2854-f856-44a2-ab47-dd2eb36699d2	Farm Fresh Eggs (ডিম)	DAIRY-EGG	\N	ceb128dc-d9f3-4f5f-a79e-def8315bcce4	d86da400-79e4-4f24-83b9-54a6728dd175	42.00	50.00	hali	398.000	40.000	\N	t	2026-08-25 17:31:36.433	2026-08-25 19:25:17.009
73b57738-ec31-4533-93b2-711d41099094	Butter Bun	\N	4CD7C85220B0	6d32573c-bbdb-4e48-bcf5-bf15afdf80eb	5d5fd9ed-32bb-4833-ba76-b784009b836d	12.00	15.00	10pcs	0.000	5.000	2026-08-29 00:00:00	t	2026-08-25 18:41:08.244	2026-08-25 19:25:17.009
f82b92fc-96a3-4e38-b44b-6ff1c72bffbb	Dudh 	8954329011013	\N	6d32573c-bbdb-4e48-bcf5-bf15afdf80eb	049327a8-e4cc-45b4-8705-664d20ce65d3	67.00	95.00	100pcs	176.000	10.000	2026-12-25 00:00:00	t	2026-08-25 12:40:27.589	2026-08-25 19:25:17.009
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_order_items (id, "purchaseOrderId", "productId", qty, "costPrice", subtotal) FROM stdin;
75f7179b-850a-43d1-81ae-32d7e7ff2477	d55e620b-2cb3-4625-a4ba-09b499b87b67	f82b92fc-96a3-4e38-b44b-6ff1c72bffbb	100.000	67.00	6700.00
c9adaadd-9b9b-4631-b306-a6429ad25668	fd6e3e10-4066-44d8-a50d-de6d8d3ca762	e055d820-052b-4772-93c3-50c65937d64f	1.000	30.00	30.00
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_orders (id, "supplierId", "invoiceNo", "totalAmount", "amountPaid", status, notes, "createdById", "createdAt", "updatedAt") FROM stdin;
d55e620b-2cb3-4625-a4ba-09b499b87b67	c6657a49-aa61-41fe-8d77-2379746f22bf	PO-1787679978714	6700.00	6700.00	PAID		7106ee9d-0557-46ba-874b-695750b7967b	2026-08-25 17:46:18.716	2026-08-25 19:25:17
fd6e3e10-4066-44d8-a50d-de6d8d3ca762	c6657a49-aa61-41fe-8d77-2379746f22bf	PO-1787684696043	30.00	0.00	PENDING		7106ee9d-0557-46ba-874b-695750b7967b	2026-08-25 19:04:56.046	2026-08-25 19:25:17
\.


--
-- Data for Name: sale_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_items (id, "saleId", "productId", qty, "unitPrice", "discountAmount", subtotal) FROM stdin;
2a5cf03d-2466-419e-91b0-c74641b646ba	7d496135-aae5-4400-88fb-7e04651672dd	f82b92fc-96a3-4e38-b44b-6ff1c72bffbb	3.000	95.00	0.00	285.00
e7820631-4dbc-4c40-8263-ec5b1bf24769	f4fa8287-7a3d-4553-85d7-27c00acba7ad	37b57595-d5d9-452b-af1b-8bb3e7537b3a	1.000	95.00	0.00	95.00
81a16e46-aa0c-424f-aec6-2fda3b7b65c3	f4fa8287-7a3d-4553-85d7-27c00acba7ad	f82b92fc-96a3-4e38-b44b-6ff1c72bffbb	1.000	95.00	0.00	95.00
adecc9b4-4c3c-4741-b9b9-671fabd70312	f4fa8287-7a3d-4553-85d7-27c00acba7ad	96aa2854-f856-44a2-ab47-dd2eb36699d2	1.000	50.00	0.00	50.00
fe2126c9-0ba2-46f0-b8db-0a21ca200430	f4fa8287-7a3d-4553-85d7-27c00acba7ad	ba857e79-cd79-4472-af17-fe5b03b29371	0.500	74.00	0.00	37.00
a901e748-9c15-4a3b-bee2-4dbf515a3909	f4fa8287-7a3d-4553-85d7-27c00acba7ad	e055d820-052b-4772-93c3-50c65937d64f	1.500	40.00	0.00	60.00
a55c6fcd-889e-4342-b28d-6835844d7eaf	4c00ac2e-1bb5-49c0-974e-fe989bddfc2d	96aa2854-f856-44a2-ab47-dd2eb36699d2	1.000	50.00	0.00	50.00
24b6de61-7257-4df8-97e6-09995d21a9ca	697011c3-9fb5-464d-a819-3d8c27632fe0	b4954a19-be5c-4be3-9ce2-c73b3e460715	0.250	90.00	0.00	22.50
\.


--
-- Data for Name: sale_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_payments (id, "saleId", method, amount, reference, "createdAt") FROM stdin;
ae8b5203-ac9e-4c47-a7ed-cb7dee307e06	7d496135-aae5-4400-88fb-7e04651672dd	CASH	285.00	\N	2026-08-25 12:40:55.59
2ff80d0c-00ce-480d-9a07-3d94e1816bf9	f4fa8287-7a3d-4553-85d7-27c00acba7ad	CASH	337.00	\N	2026-08-25 17:34:25.5
583a6609-7934-47ad-82d0-87efb520d736	4c00ac2e-1bb5-49c0-974e-fe989bddfc2d	CASH	50.00	\N	2026-08-25 19:05:34.383
47174147-50c5-4bb3-9812-d4edfd3b6919	697011c3-9fb5-464d-a819-3d8c27632fe0	CASH	22.50	\N	2026-08-25 19:07:57.701
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales (id, "invoiceNo", "cashierId", "customerId", subtotal, "discountAmount", "totalAmount", "paymentStatus", notes, "createdAt") FROM stdin;
7d496135-aae5-4400-88fb-7e04651672dd	INV-20260825-91601	7106ee9d-0557-46ba-874b-695750b7967b	\N	285.00	0.00	285.00	PAID		2026-08-25 12:40:55.59
f4fa8287-7a3d-4553-85d7-27c00acba7ad	INV-20260825-73292	7106ee9d-0557-46ba-874b-695750b7967b	\N	337.00	0.00	337.00	PAID		2026-08-25 17:34:25.5
4c00ac2e-1bb5-49c0-974e-fe989bddfc2d	INV-20260826-97236	7106ee9d-0557-46ba-874b-695750b7967b	\N	50.00	0.00	50.00	PAID		2026-08-25 19:05:34.383
697011c3-9fb5-464d-a819-3d8c27632fe0	INV-20260826-42901	7106ee9d-0557-46ba-874b-695750b7967b	\N	22.50	0.00	22.50	PAID		2026-08-25 19:07:57.701
\.


--
-- Data for Name: shift_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shift_reports (id, "cashierId", "openingFloat", "expectedCash", "actualCash", variance, "totalSales", "totalTransactions", notes, "closedAt") FROM stdin;
\.


--
-- Data for Name: stock_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_adjustments (id, "productId", qty, reason, type, "createdById", "createdAt") FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, name, contact, phone, address, "totalDue", "isActive", "createdAt", "updatedAt") FROM stdin;
c6657a49-aa61-41fe-8d77-2379746f22bf	Demo Supplier	Mr. Demo	01800000000	Dhaka, Bangladesh	30.00	t	2026-08-25 12:23:00.639	2026-08-25 19:25:16.998
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, phone, "passwordHash", role, "isActive", "createdAt", "updatedAt") FROM stdin;
7106ee9d-0557-46ba-874b-695750b7967b	Admin	01700000000	$2a$12$rHSD7g5i0ZJ6xXARR9oZNukpBLBSM8WV0Ey27GBZeHm7xCk6KQHsq	ADMIN	t	2026-08-25 12:23:00.619	2026-08-25 19:25:16.969
\.


--
-- Name: backup_logs backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_pkey PRIMARY KEY (id);


--
-- Name: brands brands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: held_carts held_carts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.held_carts
    ADD CONSTRAINT held_carts_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: sale_items sale_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_pkey PRIMARY KEY (id);


--
-- Name: sale_payments sale_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_payments
    ADD CONSTRAINT sale_payments_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: shift_reports shift_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_reports
    ADD CONSTRAINT shift_reports_pkey PRIMARY KEY (id);


--
-- Name: stock_adjustments stock_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: brands_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX brands_name_key ON public.brands USING btree (name);


--
-- Name: categories_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX categories_name_key ON public.categories USING btree (name);


--
-- Name: customers_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX customers_phone_key ON public.customers USING btree (phone);


--
-- Name: products_barcode_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_barcode_idx ON public.products USING btree (barcode);


--
-- Name: products_barcode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX products_barcode_key ON public.products USING btree (barcode);


--
-- Name: products_sku_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_sku_idx ON public.products USING btree (sku);


--
-- Name: products_sku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX products_sku_key ON public.products USING btree (sku);


--
-- Name: purchase_orders_invoiceNo_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "purchase_orders_invoiceNo_key" ON public.purchase_orders USING btree ("invoiceNo");


--
-- Name: sales_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sales_createdAt_idx" ON public.sales USING btree ("createdAt");


--
-- Name: sales_invoiceNo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sales_invoiceNo_idx" ON public.sales USING btree ("invoiceNo");


--
-- Name: sales_invoiceNo_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "sales_invoiceNo_key" ON public.sales USING btree ("invoiceNo");


--
-- Name: users_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_phone_key ON public.users USING btree (phone);


--
-- Name: held_carts held_carts_cashierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.held_carts
    ADD CONSTRAINT "held_carts_cashierId_fkey" FOREIGN KEY ("cashierId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: products products_brandId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_brandId_fkey" FOREIGN KEY ("brandId") REFERENCES public.brands(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: products products_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_order_items purchase_order_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT "purchase_order_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_order_items purchase_order_items_purchaseOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT "purchase_order_items_purchaseOrderId_fkey" FOREIGN KEY ("purchaseOrderId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_orders purchase_orders_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sale_items sale_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT "sale_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sale_items sale_items_saleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT "sale_items_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES public.sales(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sale_payments sale_payments_saleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_payments
    ADD CONSTRAINT "sale_payments_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES public.sales(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales sales_cashierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT "sales_cashierId_fkey" FOREIGN KEY ("cashierId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales sales_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT "sales_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: shift_reports shift_reports_cashierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_reports
    ADD CONSTRAINT "shift_reports_cashierId_fkey" FOREIGN KEY ("cashierId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_adjustments stock_adjustments_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT "stock_adjustments_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_adjustments stock_adjustments_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT "stock_adjustments_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict wMJ7ebV6XuID1AohilLUYnPnw5sDtIRBA1wNJ4a9UjhqMcIKH4SiawThaisgRQ3

